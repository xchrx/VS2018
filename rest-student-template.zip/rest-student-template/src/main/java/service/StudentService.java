package service;

import entity.Student;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.List;


public class StudentService {

    private static int nextStudentId = 1;

    public Student immatriculate(Student s) {

        throw new IllegalStateException("method needs to be implemented first");

    }

    public Student exmatriculate(int studentId) {

        throw new IllegalStateException("method needs to be implemented first");

    }

    public Student getStudentById(int studentId) {

        throw new IllegalStateException("method needs to be implemented first");

    }

    public Student updateStudentAccount(int nextStudentId, Student newData) {

        throw new IllegalStateException("method needs to be implemented first");

    }

    public List<Student> getAllStudents() {

        throw new IllegalStateException("method needs to be implemented first");

    }

    public List<Student> getStudentsByRange(int fromStudentId, int toStudentId) {

        throw new IllegalStateException("method needs to be implemented first");

    }
}
